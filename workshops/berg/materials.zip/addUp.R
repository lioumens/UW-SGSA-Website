            addUp_R<-function(n){
                val=0
                for (i in 1:n){
                    val=val+i
                }
                return(val)
            }